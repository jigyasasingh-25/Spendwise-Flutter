import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SpendwiseApp());
}

const ink = Color(0xFF17233C);
const muted = Color(0xFF7C879B);
const violet = Color(0xFF6658D3);
const pale = Color(0xFFF5F6FB);
const green = Color(0xFF1CA878);
const red = Color(0xFFE45D68);

class SpendwiseApp extends StatelessWidget {
  const SpendwiseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Spendwise',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: violet),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: pale,
          foregroundColor: ink,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const TrackerHome(),
    );
  }
}

class TransactionItem {
  final String id;
  final String title;
  final String category;
  final double amount;
  final bool isIncome;
  final DateTime date;

  TransactionItem({
    required this.id,
    required this.title,
    required this.category,
    required this.amount,
    required this.isIncome,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'category': category, 'amount': amount,
    'isIncome': isIncome, 'date': date.toIso8601String(),
  };

  factory TransactionItem.fromJson(Map<String, dynamic> json) =>
      TransactionItem(
        id: json['id'] as String,
        title: json['title'] as String,
        category: json['category'] as String,
        amount: (json['amount'] as num).toDouble(),
        isIncome: json['isIncome'] as bool,
        date: DateTime.parse(json['date'] as String),
      );
}

class TrackerHome extends StatefulWidget {
  const TrackerHome({super.key});

  @override
  State<TrackerHome> createState() => _TrackerHomeState();
}

class _TrackerHomeState extends State<TrackerHome> {
  int _tab = 0;
  double _monthlyBudget = 12000;
  List<TransactionItem> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('transactions');
    final budget = prefs.getDouble('monthlyBudget') ?? 12000;
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw) as List<dynamic>;
        _items = decoded.map((e) =>
            TransactionItem.fromJson(e as Map<String, dynamic>)).toList();
      } catch (_) {
        _items = [];
      }
    } else {
      final now = DateTime.now();
      _items = [
        TransactionItem(id: 'sample1', title: 'Monthly stipend', category: 'Salary',
          amount: 18000, isIncome: true, date: DateTime(now.year, now.month, 2)),
        TransactionItem(id: 'sample2', title: 'Grocery shopping', category: 'Food',
          amount: 1250, isIncome: false, date: DateTime(now.year, now.month, 5)),
        TransactionItem(id: 'sample3', title: 'College transport', category: 'Travel',
          amount: 650, isIncome: false, date: DateTime(now.year, now.month, 8)),
        TransactionItem(id: 'sample4', title: 'Online course', category: 'Education',
          amount: 999, isIncome: false, date: DateTime(now.year, now.month, 10)),
      ];
      await _saveData();
    }
    if (!mounted) return;
    setState(() {
      _monthlyBudget = budget;
      _loading = false;
    });
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('transactions',
        jsonEncode(_items.map((e) => e.toJson()).toList()));
    await prefs.setDouble('monthlyBudget', _monthlyBudget);
  }

  List<TransactionItem> get _thisMonth {
    final now = DateTime.now();
    return _items.where((t) =>
      t.date.year == now.year && t.date.month == now.month).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  double get _income => _thisMonth.where((e) => e.isIncome)
      .fold(0, (sum, e) => sum + e.amount);
  double get _expense => _thisMonth.where((e) => !e.isIncome)
      .fold(0, (sum, e) => sum + e.amount);
  double get _balance => _items.where((e) => e.isIncome)
      .fold(0, (sum, e) => sum + e.amount) -
      _items.where((e) => !e.isIncome)
      .fold(0, (sum, e) => sum + e.amount);

  String _money(double value) =>
      '₹${value.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
        (m) => '${m[1]},')}';

  Future<void> _addTransaction() async {
    final result = await showModalBottomSheet<TransactionItem>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const AddTransactionSheet(),
    );
    if (result != null) {
      setState(() => _items.add(result));
      await _saveData();
    }
  }

  Future<void> _editBudget() async {
    final controller = TextEditingController(text: _monthlyBudget.toStringAsFixed(0));
    final value = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Set monthly budget'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(prefixText: '₹ ', hintText: 'Enter amount'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () {
            final parsed = double.tryParse(controller.text.trim());
            if (parsed != null && parsed > 0) Navigator.pop(ctx, parsed);
          }, child: const Text('Save')),
        ],
      ),
    );
    if (value != null) {
      setState(() => _monthlyBudget = value);
      await _saveData();
    }
  }

  Future<void> _deleteTransaction(TransactionItem item) async {
    setState(() => _items.removeWhere((e) => e.id == item.id));
    await _saveData();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaction deleted')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _transactionsPage(),
      _analyticsPage(),
      _budgetPage(),
    ];
    return Scaffold(
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : IndexedStack(index: _tab, children: pages),
      ),
      floatingActionButton: _tab == 0 || _tab == 1
          ? FloatingActionButton.extended(
              onPressed: _addTransaction,
              backgroundColor: violet,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('Add new'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        backgroundColor: Colors.white,
        indicatorColor: violet.withOpacity(.12),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_rounded), label: 'Activity'),
          NavigationDestination(icon: Icon(Icons.pie_chart_rounded), label: 'Analytics'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_rounded), label: 'Budget'),
        ],
      ),
    );
  }

  Widget _dashboard() {
    final recent = _thisMonth.take(4).toList();
    final spentRatio = (_monthlyBudget <= 0 ? 0 : _expense / _monthlyBudget)
        .clamp(0.0, 1.0).toDouble();
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 110),
      children: [
        Row(children: [
          Container(
            height: 46, width: 46,
            decoration: BoxDecoration(color: violet, borderRadius: BorderRadius.circular(15)),
            child: const Icon(Icons.account_balance_wallet_rounded, color: Colors.white),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Spendwise', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: ink)),
            Text('Your money, in control', style: TextStyle(color: muted, fontSize: 12)),
          ])),
          CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.person_outline, color: ink)),
        ]),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF7569E7), Color(0xFF5144BD)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(25),
            boxShadow: [BoxShadow(color: violet.withOpacity(.22), blurRadius: 22, offset: const Offset(0, 10))],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TOTAL BALANCE', style: TextStyle(color: Colors.white70, letterSpacing: 1.3, fontSize: 11, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(_money(_balance), style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)),
            const SizedBox(height: 22),
            Row(children: [
              Expanded(child: _balanceMini(Icons.arrow_downward, 'Income', _money(_income))),
              Container(height: 42, width: 1, color: Colors.white24),
              const SizedBox(width: 18),
              Expanded(child: _balanceMini(Icons.arrow_upward, 'Expenses', _money(_expense))),
            ]),
          ]),
        ),
        const SizedBox(height: 24),
        Row(children: [
          const Expanded(child: Text('Monthly overview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: ink))),
          Text(_monthName(DateTime.now()), style: const TextStyle(color: muted, fontSize: 12)),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _statCard('Income', _money(_income), Icons.south_west, green)),
          const SizedBox(width: 12),
          Expanded(child: _statCard('Expenses', _money(_expense), Icons.north_east, red)),
        ]),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Text('Monthly budget', style: TextStyle(fontWeight: FontWeight.w800, color: ink, fontSize: 16))),
              TextButton(onPressed: _editBudget, child: const Text('Edit')),
            ]),
            Text('${_money(_expense)} of ${_money(_monthlyBudget)} spent',
              style: const TextStyle(color: muted, fontSize: 13)),
            const SizedBox(height: 12),
            ClipRRect(borderRadius: BorderRadius.circular(20),
              child: LinearProgressIndicator(value: spentRatio, minHeight: 10,
                backgroundColor: pale, color: spentRatio >= 1 ? red : violet)),
            const SizedBox(height: 8),
            Text('${(_monthlyBudget - _expense).clamp(0, double.infinity).toStringAsFixed(0)} left this month',
              style: const TextStyle(color: muted, fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 22),
        Row(children: [
          const Expanded(child: Text('Recent transactions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: ink))),
          TextButton(onPressed: () => setState(() => _tab = 1), child: const Text('See all')),
        ]),
        if (recent.isEmpty)
          const _EmptyState(message: 'No transactions this month. Tap Add new to get started.')
        else
          ...recent.map((item) => _transactionTile(item)),
      ],
    );
  }

  Widget _balanceMini(IconData icon, String label, String amount) => Row(children: [
    Container(width: 32, height: 32,
      decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(10)),
      child: Icon(icon, color: Colors.white, size: 17)),
    const SizedBox(width: 9),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      Text(amount, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
    ])),
  ]);

  Widget _statCard(String label, String amount, IconData icon, Color color) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(color: muted, fontSize: 12)),
      ]),
      const SizedBox(height: 10),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
        child: Text(amount, style: const TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 20))),
    ]),
  );

  Widget _transactionsPage() => ListView(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 110),
    children: [
      const Text('Activity', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: ink)),
      const SizedBox(height: 5),
      const Text('A complete record of your money', style: TextStyle(color: muted)),
      const SizedBox(height: 20),
      if (_items.isEmpty) const _EmptyState(message: 'Your transactions will appear here.')
      else ...(_items.toList()..sort((a,b) => b.date.compareTo(a.date)))
          .map((item) => _transactionTile(item, canDelete: true)),
    ],
  );

  Widget _transactionTile(TransactionItem item, {bool canDelete = false}) {
    final color = item.isIncome ? green : red;
    final icon = _categoryIcon(item.category);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
      child: Row(children: [
        Container(width: 44, height: 44,
          decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(14)),
          child: Icon(icon, color: color)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w700, color: ink)),
          const SizedBox(height: 4),
          Text('${item.category} • ${_dateLabel(item.date)}',
            style: const TextStyle(color: muted, fontSize: 11)),
        ])),
        Text('${item.isIncome ? '+' : '-'}${_money(item.amount)}',
          style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 13)),
        if (canDelete)
          IconButton(icon: const Icon(Icons.delete_outline, color: muted, size: 20),
            onPressed: () => _deleteTransaction(item)),
      ]),
    );
  }

  Widget _analyticsPage() {
    final expenses = _thisMonth.where((e) => !e.isIncome).toList();
    final totals = <String, double>{};
    for (final e in expenses) {
      totals[e.category] = (totals[e.category] ?? 0) + e.amount;
    }
    final sorted = totals.entries.toList()..sort((a,b) => b.value.compareTo(a.value));
    final colors = [violet, green, const Color(0xFFFFA64D), const Color(0xFF4D9DE0), red, const Color(0xFF9B72CF)];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
      children: [
        const Text('Analytics', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: ink)),
        const SizedBox(height: 5),
        Text('Spending breakdown • ${_monthName(DateTime.now())}', style: const TextStyle(color: muted)),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Total spent this month', style: TextStyle(color: muted)),
            const SizedBox(height: 6),
            Text(_money(_expense), style: const TextStyle(color: ink, fontSize: 29, fontWeight: FontWeight.w800)),
            const SizedBox(height: 20),
            if (sorted.isEmpty)
              const _EmptyState(message: 'Add expenses to see your spending analytics.')
            else ...sorted.asMap().entries.map((entry) {
              final index = entry.key;
              final category = entry.value;
              final ratio = _expense == 0 ? 0.0 : category.value / _expense;
              final color = colors[index % colors.length];
              return Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: Column(children: [
                  Row(children: [
                    Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(category.key, style: const TextStyle(color: ink, fontWeight: FontWeight.w600))),
                    Text('${(ratio * 100).toStringAsFixed(0)}%  •  ${_money(category.value)}',
                      style: const TextStyle(color: muted, fontSize: 12)),
                  ]),
                  const SizedBox(height: 8),
                  ClipRRect(borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(value: ratio, minHeight: 8, color: color, backgroundColor: pale)),
                ]),
              );
            }),
          ]),
        ),
        const SizedBox(height: 18),
        _statCard('Total income', _money(_income), Icons.south_west, green),
        const SizedBox(height: 10),
        _statCard('Total expenses', _money(_expense), Icons.north_east, red),
      ],
    );
  }

  Widget _budgetPage() {
    final ratio = (_monthlyBudget == 0 ? 0 : _expense / _monthlyBudget).clamp(0.0, 1.0).toDouble();
    final remaining = _monthlyBudget - _expense;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('My budget', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: ink)),
        const SizedBox(height: 5),
        const Text('Stay on track with your monthly limit', style: TextStyle(color: muted)),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('MONTHLY SPENDING LIMIT', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1)),
            const SizedBox(height: 8),
            Text(_money(_monthlyBudget), style: const TextStyle(color: ink, fontSize: 32, fontWeight: FontWeight.w800)),
            const SizedBox(height: 20),
            ClipRRect(borderRadius: BorderRadius.circular(20),
              child: LinearProgressIndicator(value: ratio, minHeight: 13, color: ratio >= 1 ? red : violet, backgroundColor: pale)),
            const SizedBox(height: 12),
            Text('${(ratio * 100).toStringAsFixed(0)}% used', style: const TextStyle(color: muted)),
            const Divider(height: 30),
            _budgetLine('Spent', _money(_expense), red),
            const SizedBox(height: 14),
            _budgetLine('Remaining', _money(remaining > 0 ? remaining : 0), green),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: _editBudget, icon: const Icon(Icons.edit_outlined),
              label: const Text('Update budget'),
              style: FilledButton.styleFrom(backgroundColor: violet, padding: const EdgeInsets.all(14)),
            )),
          ]),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(color: const Color(0xFFEDEBFF), borderRadius: BorderRadius.circular(18)),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.lightbulb_outline, color: violet),
            const SizedBox(width: 12),
            Expanded(child: Text(
              ratio >= 1 ? 'You have reached your monthly budget. Review your expenses to stay in control.'
                : 'You are doing well! Keep tracking your spending to stay within your monthly budget.',
              style: const TextStyle(color: ink, height: 1.45, fontSize: 13))),
          ]),
        ),
      ],
    );
  }

  Widget _budgetLine(String label, String amount, Color color) => Row(children: [
    Container(width: 9, height: 9, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
    const SizedBox(width: 9),
    Expanded(child: Text(label, style: const TextStyle(color: muted))),
    Text(amount, style: const TextStyle(color: ink, fontWeight: FontWeight.w700)),
  ]);

  IconData _categoryIcon(String category) {
    switch (category) {
      case 'Food': return Icons.restaurant_rounded;
      case 'Travel': return Icons.directions_bus_rounded;
      case 'Shopping': return Icons.shopping_bag_rounded;
      case 'Bills': return Icons.receipt_rounded;
      case 'Education': return Icons.school_rounded;
      case 'Salary': return Icons.account_balance_rounded;
      case 'Health': return Icons.favorite_rounded;
      default: return Icons.category_rounded;
    }
  }

  String _monthName(DateTime date) {
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    return '${months[date.month - 1]} ${date.year}';
  }

  String _dateLabel(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
}

class AddTransactionSheet extends StatefulWidget {
  const AddTransactionSheet({super.key});

  @override
  State<AddTransactionSheet> createState() => _AddTransactionSheetState();
}

class _AddTransactionSheetState extends State<AddTransactionSheet> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _amount = TextEditingController();
  bool _isIncome = false;
  String _category = 'Food';
  DateTime _date = DateTime.now();

  final _categories = ['Food', 'Travel', 'Shopping', 'Bills', 'Education', 'Health', 'Salary', 'Other'];

  @override
  void dispose() {
    _title.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final selected = await showDatePicker(
      context: context, initialDate: _date,
      firstDate: DateTime(2020), lastDate: DateTime.now(),
    );
    if (selected != null) setState(() => _date = selected);
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final item = TransactionItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: _title.text.trim(),
      category: _category,
      amount: double.parse(_amount.text.trim()),
      isIncome: _isIncome,
      date: _date,
    );
    Navigator.pop(context, item);
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(22, 12, 22, 22 + bottom),
      decoration: const BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(5)))),
            const SizedBox(height: 18),
            const Text('Add transaction', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 18),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Expense'), icon: Icon(Icons.arrow_upward)),
                ButtonSegment(value: true, label: Text('Income'), icon: Icon(Icons.arrow_downward)),
              ],
              selected: {_isIncome},
              onSelectionChanged: (v) => setState(() {
                _isIncome = v.first;
                if (_isIncome && _category == 'Food') _category = 'Salary';
                if (!_isIncome && _category == 'Salary') _category = 'Food';
              }),
            ),
            const SizedBox(height: 15),
            TextFormField(
              controller: _title,
              decoration: const InputDecoration(labelText: 'Title', hintText: 'e.g. Grocery shopping', border: OutlineInputBorder()),
              validator: (v) => v == null || v.trim().isEmpty ? 'Please enter a title' : null,
            ),
            const SizedBox(height: 13),
            TextFormField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Amount', prefixText: '₹ ', border: OutlineInputBorder()),
              validator: (v) {
                final n = double.tryParse((v ?? '').trim());
                return n == null || n <= 0 ? 'Enter a valid amount' : null;
              },
            ),
            const SizedBox(height: 13),
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()),
              items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (v) => setState(() => _category = v ?? _category),
            ),
            const SizedBox(height: 13),
            OutlinedButton.icon(
              onPressed: _pickDate,
              icon: const Icon(Icons.calendar_today_outlined),
              label: Text('Date: ${_date.day}/${_date.month}/${_date.year}'),
            ),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(
              onPressed: _submit,
              style: FilledButton.styleFrom(backgroundColor: violet, padding: const EdgeInsets.all(15)),
              child: const Text('Save transaction'),
            )),
          ]),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String message;
  const _EmptyState({required this.message});

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(24),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(children: [
      Icon(Icons.receipt_long_outlined, size: 34, color: violet.withOpacity(.7)),
      const SizedBox(height: 10),
      Text(message, textAlign: TextAlign.center,
        style: const TextStyle(color: muted, height: 1.4)),
    ]),
  );
}
