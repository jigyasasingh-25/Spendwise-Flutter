# Spendwise – Personal Expense Tracker (Flutter & Dart)

## Project overview
Spendwise is an individual mini project for Mobile Application Development. It helps users record income and expenses, review transaction history, view category-wise spending, and manage a monthly budget.

## Features
- Dashboard showing total balance, monthly income and expenses
- Add income or expense transactions
- Category selection and transaction date selection
- View and delete transaction history
- Monthly spending analytics by category
- Set and update a monthly budget
- Local persistence using SharedPreferences (data remains after closing the app)
- Sample transactions on first launch so the dashboard is not empty

## Requirements
- Flutter SDK (stable channel)
- Dart SDK (included with Flutter)
- Android Studio with Android SDK, or VS Code with Flutter extensions
- Android phone and USB cable (for direct installation), or Android emulator

## Run the project
1. Extract `Spendwise_Flutter_Project.zip`.
2. Open the `spendwise_flutter` folder in Android Studio or VS Code.
3. Open a terminal in that folder.
4. Run:
   ```bash
   flutter doctor
   flutter pub get
   flutter run
   ```
5. Connect your Android phone with USB debugging enabled, or start an emulator.

## Generate the APK
Run this command from the project folder:
```bash
flutter build apk --release
```
The APK will be created at:
`build/app/outputs/flutter-apk/app-release.apk`

To install it on a connected phone:
```bash
flutter install
```
Alternatively, copy `app-release.apk` to your phone, open it, and allow installation from that file manager if Android asks.

## Project structure
```text
spendwise_flutter/
├── lib/
│   └── main.dart
├── assets/
├── pubspec.yaml
└── README.md
```

## Data storage
The app uses the `shared_preferences` package to store transactions as JSON and the monthly budget locally on the device. No account or internet connection is required.

## Suggested project explanation
"Spendwise is a Flutter-based personal expense tracking application developed using Dart. The application allows users to record income and expenses, categorize transactions, monitor monthly spending, and set a budget. SharedPreferences is used for local data persistence so that information remains available after the application is closed."

## Important notes
- The APK is generated locally using the Flutter SDK; this source package does not contain a prebuilt APK.
- The initial sample transactions are demonstration data. They can be deleted from the Activity screen.
- Currency is displayed in Indian Rupees (INR).
